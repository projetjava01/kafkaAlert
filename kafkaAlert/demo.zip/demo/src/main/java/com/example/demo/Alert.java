package com.example.demo;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

@Entity
public class Alert {

    @Id
    @GeneratedValue
    private Long id;
    private String motCle;
    private String emailUtilisateur;

    // Constructeur par défaut (obligatoire pour JPA)
    public Alert() {
    }

    // Constructeur avec paramètres
    public Alert(String motCle, String emailUtilisateur) {
        this.motCle = motCle;
        this.emailUtilisateur = emailUtilisateur;
    }

    // Getters et Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getMotCle() {
        return motCle;
    }

    public void setMotCle(String motCle) {
        this.motCle = motCle;
    }

    public String getEmailUtilisateur() {
        return emailUtilisateur;
    }

    public void setEmailUtilisateur(String emailUtilisateur) {
        this.emailUtilisateur = emailUtilisateur;
    }
}
