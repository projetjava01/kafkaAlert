package com.example.demo;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/alertes")
public class AlertController {

    private final AlertService alertService;

    public AlertController(AlertService alertService) {
        this.alertService = alertService;
    }

    // Créer une alerte
    @PostMapping
    public ResponseEntity<Alert> creerAlerte(@RequestBody Alert alert) {
        Alert createdAlert = alertService.creerAlerte(alert.getMotCle(), alert.getEmailUtilisateur());
        return ResponseEntity.ok(createdAlert);
    }

    // Obtenir toutes les alertes
    @GetMapping
    public ResponseEntity<List<Alert>> getAllAlerts() {
        List<Alert> alerts = alertService.obtenirToutesLesAlertes();
        return ResponseEntity.ok(alerts);
    }
}
