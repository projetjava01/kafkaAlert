package com.example.demo;

import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AlertService {

    private final AlertRepository alertRepository;
    private final KafkaProducerService kafkaProducerService;

    public AlertService(AlertRepository alertRepository, KafkaProducerService kafkaProducerService) {
        this.alertRepository = alertRepository;
        this.kafkaProducerService = kafkaProducerService;
    }

    public Alert creerAlerte(String motCle, String emailUtilisateur) {
        Alert alert = new Alert(motCle, emailUtilisateur);
        Alert nouvelleAlerte = alertRepository.save(alert);

        // Envoyer un message à Kafka
        kafkaProducerService.envoyerMessage("Nouvelle alerte créée pour le mot-clé : " + motCle);

        return nouvelleAlerte;
    }

    public List<Alert> obtenirToutesLesAlertes() {
        return alertRepository.findAll();
    }
}
